# OS Benchmarking Tool
 A tool which stresses the CPU and compares the performance of computing devices having different hardware and operating systems, using image processing and various other compute intensive tasks. 

To run the code, cd to the OS_Project directory and execute the command:
## ```streamlit run OS_Benchmarking_tool.py```

If you don't have streamlit, run the command:
## ```pip install streamlit```
